﻿using System.Runtime.CompilerServices;

namespace AutoDrivingCarSimulation
{
    class Program
    {
        public static void Main(string[] args)
        {
            Simulation simulation = ExecuteSimulation();

            while (true)
            {
                Console.WriteLine("\nPlease choose from the following options:");
                Console.WriteLine("[1] Add a car to field");
                Console.WriteLine("[2] Run simulation");


                string choice = Console.ReadLine()!;
                if (choice == "1")
                {
                    Console.Write("Please enter the name of the car: ");
                    string name = Console.ReadLine()!;

                    Console.Write($"Please enter initial position of car {name} in x y Direction format: ");
                    string[] positionInput = Console.ReadLine()!.Split();
                    int x = int.Parse(positionInput[0]);
                    int y = int.Parse(positionInput[1]);
                    char direction = char.ToUpper(positionInput[2][0]);

                    Console.Write($"Please enter the commands for car {name} : ");
                    string commands = Console.ReadLine()!.ToUpper();

                    simulation.AddCar(new Car(name, x, y, direction, commands));
                }
                else if (choice == "2")
                {
                    simulation.Run();

                    string restartChoice = Console.ReadLine()!;
                    if (restartChoice == "1")
                    {
                        simulation = ExecuteSimulation(); ; // Reset simulation
                        Console.WriteLine("\nStarting over...");
                    }
                    else if (restartChoice == "2")
                    {
                        Console.WriteLine("Thank you for running the simulation. Goodbye!");
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Exit!");
                }
            }

            Simulation ExecuteSimulation()
            {
                Console.WriteLine("Welcome to Auto Driving Car Simulation!");
                Console.Write("Please enter the width and height of the simulation field in x y format: ");

                string[] dimensions = Console.ReadLine()!.Split();
                int width = int.Parse(dimensions[0]);
                int height = int.Parse(dimensions[1]);

                Console.WriteLine($"\n You have created a field of: {width} x {height}");

                return new Simulation(width, height);
            }
        }
    }
}
