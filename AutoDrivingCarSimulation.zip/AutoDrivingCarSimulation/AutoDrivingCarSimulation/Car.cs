﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoDrivingCarSimulation
{
    public class Car
    {
        public string Name { get; }
        public int X { get; private set; }
        public int Y { get; private set; }
        public char Direction { get; private set; }
        public string Commands { get; }
        public bool Collided { get; set; }
        public string? CollidedWith { get; set; }  


        private static readonly Dictionary<char, (int dx, int dy)> MoveMap = new()
    {
        { 'N', (0, 1) }, { 'S', (0, -1) }, { 'E', (1, 0) }, { 'W', (-1, 0) }
    };

        private static readonly Dictionary<char, Dictionary<char, char>> RotateMap = new()
    {
        { 'L', new() { { 'N', 'W' }, { 'W', 'S' }, { 'S', 'E' }, { 'E', 'N' } } },
        { 'R', new() { { 'N', 'E' }, { 'E', 'S' }, { 'S', 'W' }, { 'W', 'N' } } }
    };

        public Car(string name, int x, int y, char direction, string commands)
        {
            Name = name;
            X = x;
            Y = y;
            Direction = direction;
            Commands = commands;
            Collided = false;
            CollidedWith = null;
        }

        public void Move()
        {
            if (Collided) return;
            (int dx, int dy) = MoveMap[Direction];
            X += dx;
            Y += dy;
        }

        public (int, int) NextPosition()
        {
            if (Collided) return (X, Y);
            (int dx, int dy) = MoveMap[Direction];
            return (X + dx, Y + dy);
        }

        public void Rotate(char turn)
        {
            if (Collided) return;
            Direction = RotateMap[turn][Direction];
        }
    }
}
