﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace AutoDrivingCarSimulation
{
    public class Simulation
    {
        private readonly int _width;
        private readonly int _height;
        private readonly List<Car> _cars = new();
        public Simulation(int width, int height) 
        {
            _width = width;
            _height = height;
        }

        public void AddCar(Car car)
        {
            _cars.Add(car);
            DisplayListofCars();
        }

        private void DisplayListofCars()
        {
            Console.WriteLine("\nYour current list of cars are:");
            foreach (var c in _cars)
            {
                Console.WriteLine($"\n - {c.Name}, ({c.X},{c.Y}) {c.Direction}, {c.Commands}");
            }
        }
        public void Run()
        {
            
            DisplayListofCars();

            Dictionary<(int, int), Car> positions = new();
            int maxSteps = 0;
            foreach (var car in _cars)
            {
                positions[(car.X, car.Y)] = car;
                maxSteps = Math.Max(maxSteps, car.Commands.Length);
            }
            Console.WriteLine("\nAfter simulation, the result is:");

            // Simulate each step.
            for (int step = 0; step < maxSteps; step++)
            {
               
                List<(Car car, int newX, int newY)> movements = new();

                foreach (var car in _cars)
                {
                    if (step >= car.Commands.Length || car.Collided)
                        continue; 

                    char command = car.Commands[step];
                    if (command == 'L' || command == 'R')
                    {
                        car.Rotate(command); 
                        continue;
                    }

                    // Get the new position
                    (int newX, int newY) = car.NextPosition();
                    if (newX < 0 || newX >= _width || newY < 0 || newY >= _height)
                        continue; // Skip out-of-bounds moves.

                    movements.Add((car, newX, newY));
                }

                // check for collisions before updating positions.
                HashSet<(int, int)> occupiedPositions = new(); // Set to track occupied positions for collision detection.
                Dictionary<(int, int), Car> nextPositions = new(); // Map to track next position of cars.

                foreach (var (car, newX, newY) in movements)
                {
                    if (nextPositions.ContainsKey((newX, newY)) || positions.ContainsKey((newX, newY)))
                    {
                        // Find the other car occupying the position.
                        Car otherCar = nextPositions.ContainsKey((newX, newY)) ? nextPositions[(newX, newY)] : positions[(newX, newY)];

                        // Handle collision for both cars.
                        car.Collided = true;
                        car.CollidedWith = otherCar.Name;
                        otherCar.Collided = true;
                        otherCar.CollidedWith = car.Name;

                        // collision details
                        Console.WriteLine($"- {otherCar.Name} collides with {car.Name} at ({newX}, {newY}) at step {step + 1}");
                        Console.WriteLine($"- {car.Name} collides with {otherCar.Name} at ({newX}, {newY}) at step {step + 1}");
                       
                    }
                    else
                    {
                        nextPositions[(newX, newY)] = car;
                    }
                }

                // Now update the positions of cars that haven't collided.
                foreach (var (car, newX, newY) in movements)
                {
                    if (!car.Collided)
                    {
                        positions.Remove((car.X, car.Y));
                        car.Move();
                        positions[(car.X, car.Y)] = car; 
                    }
                }
            }

            foreach (var car in _cars)
            {
                if (!car.Collided)
                {
                    Console.WriteLine($"- {car.Name}, ({car.X},{car.Y}) {car.Direction}");
                }
            }

            Console.WriteLine("\nPlease choose from the following options:");
            Console.WriteLine("[1] Start over");
            Console.WriteLine("[2] Exit");
        }

    }
}
