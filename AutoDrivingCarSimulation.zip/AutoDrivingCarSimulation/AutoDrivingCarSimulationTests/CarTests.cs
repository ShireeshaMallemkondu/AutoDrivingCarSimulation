﻿using AutoDrivingCarSimulation;
using NUnit.Framework;

namespace AutoDrivingCarSimulationTests
{
    [TestFixture]
    public class CarTests
    {
        private Car _car;

        [SetUp]
        public void Setup()
        {
            _car = new Car("A", 1, 2, 'N', "FFRFFFFRRL");
        }

        [Test]
        public void TestInitialPositionAndDirection() // Test if the car's initial position and direction are set correctly
        {
            Assert.AreEqual(1, _car.X);
            Assert.AreEqual(2, _car.Y);
            Assert.AreEqual('N', _car.Direction);
        }

        [Test]
        // Test if the car moves North correctly
        public void TestMoveCarNorth()
        {
            _car.Move();
            Assert.AreEqual(1, _car.X);
            Assert.AreEqual(3, _car.Y);
        }

        [Test]
        // Test if the car moves East correctly after a right turn
        public void TestMoveCarEast()
        {

            _car.Rotate('R');
            _car.Move();
            Assert.AreEqual(2, _car.X);
            Assert.AreEqual(2, _car.Y);
        }

        [Test]
        // Test if the car rotates correctly to the left
        public void TestRotateCarLeft()
        {

            _car.Rotate('L');
            Assert.AreEqual('W', _car.Direction);
        }

        [Test]
        // Test if the car rotates correctly to the right
        public void TestRotateCarRight()
        {
            _car.Rotate('R');
            Assert.AreEqual('E', _car.Direction);
        }

        [Test]
        // Test  executing multiple commands
        public void TestMoveMultipleCommands()
        {
            _car.Move();  
            _car.Rotate('R');  
            _car.Move();  
            _car.Rotate('R'); 
            _car.Move(); 

            Assert.AreEqual(2, _car.X);  
            Assert.AreEqual(2, _car.Y); 
            Assert.AreEqual('S', _car.Direction); 
        }

        [Test]
        public void TestNextPositionWithoutMoving()
        {
            var (nextX, nextY) = _car.NextPosition();
            Assert.AreEqual(1, nextX);
            Assert.AreEqual(3, nextY);
        }

        [Test]
        public void TestCarCollidedFlag()
        {
            // collision behavior test
            _car.Collided = true;
            _car.Move();  
            Assert.AreEqual(1, _car.X);
            Assert.AreEqual(2, _car.Y);
        }

    }
}
