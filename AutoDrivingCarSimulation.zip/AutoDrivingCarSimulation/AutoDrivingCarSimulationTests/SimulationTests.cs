﻿using AutoDrivingCarSimulation;
using NUnit.Framework;
namespace AutoDrivingCarSimulationTests
{
    public class SimulatorTests
    {
        private Simulation _simulation;

        [SetUp]
        public void Setup()
        {
            _simulation = new Simulation(10, 10);
        }

        [Test]
        public void SingleCar_ShouldMoveCorrectly()
        {
            var car = new Car("A", 1, 2, 'N', "FFRFFFFRRL");
            _simulation.AddCar(car);

            _simulation.Run();

            Assert.AreEqual(5, car.X);
            Assert.AreEqual(4, car.Y);
            Assert.AreEqual('S', car.Direction);
            Assert.IsFalse(car.Collided);
        }

        [Test]
        public void Cars_ShouldStopOnCollision()
        {
            var carA = new Car("A", 1, 2, 'N', "FFRFFFFRRL");
            var carB = new Car("B", 7, 8, 'W', "FFLFFFFFFF");

            _simulation.AddCar(carA);
            _simulation.AddCar(carB);

            _simulation.Run();

            Assert.IsTrue(carA.Collided);
            Assert.IsTrue(carB.Collided);
            Assert.AreEqual("B", carA.CollidedWith);
            Assert.AreEqual("A", carB.CollidedWith);
            Assert.AreEqual(4, carA.X);
            Assert.AreEqual(4, carA.Y);
            Assert.AreEqual(5, carB.X);
            Assert.AreEqual(5, carB.Y);
        }

        [Test]
        public void Car_ShouldIgnoreMoveOutOfBounds()
        {
            var car = new Car("C", 0, 0, 'S', "F");
            _simulation.AddCar(car);

            _simulation.Run();

            Assert.AreEqual(0, car.X);
            Assert.AreEqual(0, car.Y);
        }
    }
}
